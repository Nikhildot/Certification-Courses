﻿using System.Collections.Generic;

namespace HTMLTOJSON
{
    public class CaseModel
    {
        public string CaseNumber { get; set; }
        public string CourtCaseType { get; set; }
        public string FilingDate { get; set; }
        public string Jurisdiction { get; set; }
        public string JudgeName { get; set; }
        public List<Defendant> Defendants { get; set; }
        public string FeesOwed { get; set; }
        public string FeesPaid { get; set; }
        public string FeesDue { get; set; }
    }
    public class Defendant
    {
        public string NameRaw { get; set; }
        public string Race { get; set; }
        public string DOBRaw { get; set; }
        public string Height { get; set; }
        public string Weight { get; set; }
        public List<Charges> Charges { get; set; }
    }

    public class Charges
    {
        public string CountNumber { get; set; }
        public string StatuteDescription { get; set; }
        public string Statute { get; set; }
        public string ChargeDegree { get; set; }
        public string ChargeLevel { get; set; }
        public string OffenseDate { get; set; }
        public string DispositionDate { get; set; }
        public string DispositionDetail { get; set; }
    }
}
