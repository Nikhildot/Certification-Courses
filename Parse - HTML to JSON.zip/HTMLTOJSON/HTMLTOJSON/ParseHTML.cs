﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;

namespace HTMLTOJSON
{
    public class ParseHTML
    {
        public CaseModel ParseHTMLToJson(string htmlfile)
        {
            var objCase = new CaseModel();
            var charges = new Charges();
            var defendant = new Defendant();
            var listCharge = new List<Charges>();
            var listDefendant = new List<Defendant>();
            try
            {
                HtmlWeb web = new HtmlWeb();
                HtmlDocument document = web.Load(Convert.ToString(htmlfile));

                var casenumber = document.DocumentNode.SelectSingleNode(@"/html/body/div/span");
                objCase.CaseNumber = casenumber != null ? StringUtility.StrReplace(casenumber.InnerText).Trim() : "";

                var CaseType = document.DocumentNode.SelectSingleNode(@"/html/body/table[3]/tr/td/table/tr/td/table/tr/td/b");
                objCase.CourtCaseType = CaseType != null ? StringUtility.StrReplace(CaseType.InnerText).Trim() : "";

                var FilingDate = document.DocumentNode.SelectSingleNode(@"/html/body/table[3]/tr/td/table/tr/td/table/tr[2]/td/b");
                objCase.FilingDate = FilingDate.InnerText.ToString();

                var Jurisdiction = document.DocumentNode.SelectSingleNode(@"/html/body/table[3]/tr/td/table/tr/td/table/tr[3]/td/b");
                objCase.Jurisdiction = Jurisdiction != null ? StringUtility.StrReplace(Jurisdiction.InnerText).Trim() : "";

                var JudgeName = document.DocumentNode.SelectSingleNode(@"/html/body/table[3]/tr/td/table/tr/td/table/tr[4]/td/b");
                objCase.JudgeName = JudgeName != null ? StringUtility.StrReplace(JudgeName.InnerText).Trim() : "";

                var FeesOwed = document.DocumentNode.SelectSingleNode(@"/html/body/table[7]/tr[5]/td[4]");
                objCase.FeesOwed = FeesOwed != null ? StringUtility.StrReplace(FeesOwed.InnerText).Trim() : "";

                var FeesPaid = document.DocumentNode.SelectSingleNode(@"/html/body/table[7]/tr[6]/td[4]");
                objCase.FeesPaid = FeesPaid != null ? StringUtility.StrReplace(FeesPaid.InnerText).Trim() : "";

                var FeesDue = document.DocumentNode.SelectSingleNode(@"/html/body/table[7]/tr[7]/td[4]");
                objCase.FeesDue = FeesDue != null ? StringUtility.StrReplace(FeesDue.InnerText).Trim() : "";

                var NameRaw = document.DocumentNode.SelectSingleNode(@"/html/body/table/tr/th[2]/a");
                defendant.NameRaw = NameRaw.InnerText;

                var Race = document.DocumentNode.SelectSingleNode(@"/html/body/table[4]/tr[2]/td[2]");
                string[] infoList = Race.InnerHtml.Split("<br>");
                if (infoList != null && infoList.Length > 0)  defendant.Race = infoList[0];
                string[] doblist = infoList[1].Split(":");
                defendant.DOBRaw = doblist[1];
                string[] hwlist = infoList[2].Split(",");
                defendant.Height = hwlist[0];
                defendant.Weight = hwlist[1];

                var CountNumber = document.DocumentNode.SelectSingleNode(@"/html/body/table[5]/tr[2]/td[1]");
                charges.CountNumber = CountNumber != null ? StringUtility.StrReplace(CountNumber.InnerText).Trim() : "";

                var StatuteDescription = document.DocumentNode.SelectSingleNode(@"/html/body/table[5]/tr[2]/td[2]");
                charges.StatuteDescription = StatuteDescription != null ? StringUtility.StrReplace(StatuteDescription.InnerText).Trim() : "";

                var Statute = document.DocumentNode.SelectSingleNode(@"/html/body/table[5]/tr[2]/td[4]");
                charges.Statute = Statute != null ? StringUtility.StrReplace(Statute.InnerText).Trim() : "";

                var ChargeDegree = document.DocumentNode.SelectSingleNode(@"/html/body/table[5]/tr[2]/td[5]");
                string[] nameList = ChargeDegree.InnerText.Split(" ");
                charges.ChargeDegree = nameList[0] + " " + nameList[1];
                charges.ChargeLevel = nameList[2];

                var OffenseDate = document.DocumentNode.SelectSingleNode(@"/html/body/table[5]/tr[2]/td[6]");
                charges.OffenseDate = OffenseDate != null ? StringUtility.StrReplace(OffenseDate.InnerText).Trim() : "";

                var DispositionDate = document.DocumentNode.SelectSingleNode(@"/html/body/table[6]/tr[5]/th");
                charges.DispositionDate = DispositionDate != null ? StringUtility.StrReplace(DispositionDate.InnerText).Trim() : "";

                var DispositionDetail = document.DocumentNode.SelectSingleNode(@"/html/body/table[6]/tr[5]/td[3]/div/div/div/div[1]");
                charges.DispositionDetail = DispositionDetail != null ? StringUtility.StrReplace(DispositionDetail.InnerText).Trim() : "";

                listCharge.Add(charges);
                defendant.Charges = listCharge;
                listDefendant.Add(defendant);
                objCase.Defendants = listDefendant;
            }
            catch (Exception)
            {

                throw;
            }
            return objCase;
        }
    }
}
