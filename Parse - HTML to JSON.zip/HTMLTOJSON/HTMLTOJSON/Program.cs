﻿using System.IO;
using Newtonsoft.Json;

namespace HTMLTOJSON
{
    class Program
    {
        static void Main(string[] args)
        {
            string dir = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
           string htmlfile = dir + "\\Parse Sample.html";
            ParseHTML obj = new ParseHTML();
            var objcase = obj.ParseHTMLToJson(htmlfile);
            JsonSerializer serializer = new JsonSerializer();
            serializer.NullValueHandling = NullValueHandling.Ignore;
            using (StreamWriter sw = new StreamWriter(dir+"\\json_output.json"))
            using (JsonWriter writer = new JsonTextWriter(sw))
            {
                serializer.Serialize(writer, objcase);
            }
        }
    }
}
