﻿using System.Web;

namespace HTMLTOJSON
{
    static class StringUtility
    {
        public static string StrReplace(string value)
        {
            return HttpUtility.HtmlDecode(value).Trim();
        }
    }
}
